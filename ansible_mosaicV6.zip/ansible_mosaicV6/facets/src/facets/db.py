import os
import json
import happybase

from facets.conf import settings
from importlib import import_module
from sqlalchemy import create_engine
from cached_property import cached_property


class SqlAlchemy(object):

    def __init__(self, data_source, limit=5000):
        """ Initialize the class """
        self.data_source = data_source
        self.limit = limit

    def __del__(self):
        """ Close the connection """
        try:
            self.connection.close()
        except Exception as ex:
            pass

    @cached_property
    def connection_string(self):
        """ Connection string to be used """
        raise NotImplemented

    @cached_property
    def engine(self):
        """ create sqlalchemy engine """
        return create_engine(self.connection_string)

    @cached_property
    def connection(self):
        """ sqlalchemy connection """
        return self.engine.connect()


class Configuration(SqlAlchemy):

    @cached_property
    def connection_string(self):
        return 'mysql://{}:{}@{}:{}/{}'.format(
            settings.MYSQL.get('username'),
            settings.MYSQL.get('password'),
            settings.MYSQL.get('host'),
            settings.MYSQL.get('port'),
            settings.MYSQL.get('database'),
        )

    @cached_property
    def configuration(self):
        query = 'select json from configuration where name = \'{}\' limit 1;'.format(self.data_source)
        result = [x for x in self.connection.execute(query)][0][0]
        return json.loads(result.decode('utf-8'), strict=False)

    @cached_property
    def file_store_object(self):
        return self.configuration.get('fileStoreObject')


class HiveTable(SqlAlchemy):

    @cached_property
    def connection_string(self):
        return 'hive://{}:{}/{}'.format(
            settings.HIVE.get('host'),
            settings.HIVE.get('port'),
            settings.HIVE.get('database'),
        )

    @cached_property
    def headers(self):
        query = 'SHOW COLUMNS IN {}'.format(self.data_source)
        return self.connection.execute(query)

    @cached_property
    def records(self):
        """ records from the given data source """
        query = 'SELECT * FROM {} LIMIT {}'.format(self.data_source, self.limit)
        return self.connection.execute(query)


class HbaseTable(object):

    def __init__(self, data_source, limit=5000):
        self.data_source = data_source.upper()
        self.limit = limit

    def __del__(self):
        try:
            self.connection.close()
        except Exception as ex:
            pass

    @cached_property
    def connection(self):
        return happybase.Connection(settings.HBASE.get('host'))

    @cached_property
    def table(self):
        return happybase.Table(self.data_source, self.connection)

    @cached_property
    def headers(self):
        for key, data in self.table.scan():
             return data.keys()

    @cached_property
    def records(self):
        count = 0
        records = []
        for key, data in self.table.scan():
            records.append(data)
            count += 1
            if count >= self.limit:
                break
        return records
