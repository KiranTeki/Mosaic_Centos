#! /usr/bin/env/python
from __future__ import print_function

import os
import sys

from flask import Flask
from facets.conf import settings
from facets.app import app as facets


here = os.path.dirname(__file__)
bin = sys.executable.rsplit(os.path.sep, 1)[0]


def run_server():
    """ run flask development server """
    app = Flask('facets-flask-app', static_url_path='/static')
    app.register_blueprint(facets)
    app.run(host=settings.HOST, port=settings.PORT, debug=settings.DEBUG, threaded=settings.THREADED)


def generate_configs():
    """ generate var config files """
    args = sys.argv
    if '--initd' in args:
        generate_dirs()
        generate_initd()
        generate_logrotated()
    if '--systemd' in args:
        generate_systemd()
    if '--logrotated' in args:
        generate_logrotated()
    if '--help' in args:
        print('facets-generate-configs [--initd, --systemd, --logrotated, --help]')


def generate_dirs():
    """ generate log and run directories """
    if not os.path.exists('/var/log/facets'):
        os.mkdir('/var/log/facets')
    if not os.path.exists('/var/run/facets'):
        os.mkdir('/var/run/facets')


def generate_initd():
    """ generate initd config files """
    service_folder = '/etc/init.d/'
    service_file = service_folder + 'facets.service'
    if not os.path.exists(service_folder):
        return
    template_file = os.path.join(here, 'configs', 'init.d', 'facets.template')
    template_content = open(template_file, 'r').read()
    service_content = template_content.format(bin=bin)
    with open(service_file, 'w') as f:
        f.write(service_content)


def generate_systemd():
    """ generate systemd config files """
    service_folder = '/etc/systemd/system/'
    service_file = service_folder + 'facets.service'
    if not os.path.exists(service_folder):
        return
    template_file = os.path.join(here, 'configs', 'systemd', 'facets.template')
    template_content = open(template_file, 'r').read()
    service_content = template_content.format(bin=bin)
    with open(service_file, 'w') as f:
        f.write(service_content)


def generate_logrotated():
    """ generate logrotated config files """
    service_folder = '/etc/logrotate.d/'
    serfice_file = service_folder + 'facets.service'
    if not os.path.exists(service_folder):
        return
    template_file = os.path.join(here, 'configs', 'logrotate.d', 'facets.template')
    template_content = open(template_file, 'r').read()
    service_content = template_content.format()
    with open(service_file, 'w') as f:
        f.write(service_content)
