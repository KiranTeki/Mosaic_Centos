HOST = '0.0.0.0'

PORT = 8000

DEBUG = True

THREADED = True

