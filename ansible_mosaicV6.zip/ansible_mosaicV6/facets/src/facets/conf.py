import os

from importlib import import_module

settings_module = os.getenv('FACETS_SETTINGS_MODULE', 'facets.settings.production')
settings = import_module(settings_module)
