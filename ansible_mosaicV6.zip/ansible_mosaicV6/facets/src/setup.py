from os import path
from codecs import open
from setuptools import setup, find_packages


setup(
    name='facets',
    version='1.0.1',
    description='facets visualization for machine learning',
    long_description='visit https://github.com/PAIR-code/facets for more details',
    url='https://bitbucket.org/maxiqdev/facets',
    author='Akhil Lawrence',
    author_email='akhil.lawrence@lntinfotech.com',
    license='MIT',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Other Audience',
        'Topic :: Multimedia :: Graphics :: Presentation',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
    ],
    keywords='facets visualization',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'sasl==0.2.1',
        'sklearn==0.0',
        'pyhive==0.4.0',
        'flask==0.12.2',
        'numpy==1.13.1',
        'scipy==0.19.1',
        'future==0.16.0',
        'thrift==0.10.0',
        'pandas==0.20.3',
        'protobuf==3.3.0',
        'happybase==1.1.0',
        'thrift-sasl==0.3.0',
        'sqlalchemy==1.1.12',
        'mysql-python==1.2.5',
        'cached-property==1.3.0',
    ],
    entry_points={
        'console_scripts': [
            'facets-run-server=facets.commands:run_server',
            'facets-generate-configs=facets.commands:generate_configs',
        ],
    },
)
